///Implemente a classe Funcionario com nome, salário e os métodos
///addAumento(double valor), ganhoAnual() e exibeDados() - imprime os valores do funcionário.

/// Classe principal.
class Funcionario {


    var nome: String?
    var salario: Double?
  
    init(nome: String, salario: Double) {
        self.nome = nome
        self.salario = salario
        
    }
/// Função que adiciona o aumento.
    func addAumento() -> Double {
        salario! * 1.3
    }

/// Função que calcula os ganhos anuais.
    func ganhoAnual() -> Double {
        return salario! * 12
    }

/// Função que exibe os dados.
    func exibeDados() {
        print("Nome: ", nome!)
        print("Salário: ", salario!)
    }
}

/// a. crie a classe Assistente, que também é um funcionário, e que possui um número de
///    matrícula (faça os métodos GET e SET). Sobrescreva o método exibeDados().
/// Classe Assistente
class Assistente : Funcionario {
  
    var matricula: Int

    init(matricula: Int, nome: String, salario: Double) {
        self.matricula = matricula
        super.init(nome: nome, salario: salario)
        
    }
/// Função que exibe os dados
    override func exibeDados() {
        print("Matrícula: \(matricula)")
        print("Nome:  \(nome!)")
        print("Salário:  \(salario!)")
        print("Ganho Anual: R$ \(ganhoAnual())")
        print("Aumento: R$ \(addAumento())")
        print("Turno:  Diurno")
    }
}
/// b. sabendo que os Assistentes Técnicos possuem um bônus salarial e que os Assistentes
///  Administrativos possuem um turno (dia ou noite) e um adicional noturno, crie as classes
///  Tecnico e Administrativo e sobrescreva o método ganhoAnual() de ambas as classes
///  (Administrativo e Tecnico).
///  classe Tecnico
class Tecnico: Assistente {

    var bonusSalarial: Double

    init(matricula: Int, nome: String, salario: Double, bonusSalarial: Double) {
        self.bonusSalarial = bonusSalarial
        super.init(matricula: matricula, nome: nome, salario: salario)
    }
    override func ganhoAnual() -> Double {
        let ganhoAnual = ((salario! * 1.3) * 12) + bonusSalarial
        return ganhoAnual
    }

}
      
/// Classe Administrativo
class Administrativo: Assistente {

    var turno: String

    init(matricula: Int, nome: String, salario: Double, turno: String) {
        self.turno = turno
        super.init(matricula: matricula, nome: nome, salario: salario)
    }

    override func ganhoAnual() -> Double {
            var ganhoAnual = ((salario! + (salario! * 2.0)) * 20.0)

        if turno == "Diurno" {
            ganhoAnual = super.ganhoAnual()
        }
        return ganhoAnual
    }

}
print("****** Assistente ******")
var funcionario1 = Tecnico(matricula: 147, nome: "Adão", salario: 1700.0, bonusSalarial: 1.2)

    funcionario1.exibeDados()

print("****** Administrativo *******")
var funcionario2 = Administrativo(matricula: 5252, nome: "Charlene Fabri", salario: 2000.3, turno: "Diurno")
    
    funcionario2.exibeDados()

print("****** Tecnico ******")
var funcionario3 = Tecnico(matricula: 8795, nome: "Jorge Mateus", salario: 1500.0, bonusSalarial: 1.5)

    funcionario3.exibeDados()
