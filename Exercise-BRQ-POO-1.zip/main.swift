//////////// Exercício (2-A)

/// Classe principal

class Animal {
  
    var nome : String? 
    var raca : String?

    init(nome: String, raca: String) {
        self.nome = nome
        self.raca = raca
    }
  
    func caminha () {
        print("Animal: \(raca!), caminhou")
    }
  
}

class Cachorro: Animal {

    func late () {
      print("Cachorro: \(nome!), late bastante")   
    }
}

class Gato : Animal { 
  
     func miou() {
        print("Gato: \(nome!), miou muito alto")
     
     }
  
}
/// classe cachorro 
var dog = Cachorro(nome: "Max", raca: "Pit Bull")

    dog.late()
    dog.caminha()
    print("")

/// classe gato
var felina = Gato(nome: "Berenice", raca: "Vira lata")
    
    felina.miou()
    felina.caminha()


//////////// Exercício (2-B)

class Pessoa {
  
    var nome: String?
    var idade: Int?

    init(nome: String, idade: Int) {
        self.nome = nome
        self.idade = idade
    
    }
    func viver() {
        print(" \(nome!), pessoa")
    }
  
}
print("")
print("****** Rica ******")
class Rica : Pessoa {
  
    var dinheiro: Double? = 1.200

    init(nome: String, idade: Int, dinheiro: Double) {
        self.dinheiro = dinheiro
        super.init(nome: nome, idade: idade)
    }
  
    func fazCompras() {       
        print("\(idade!), anos")
        print("Faz muitas compras, e tem: \(dinheiro!), reais")
    }
    
}
var ricao = Rica(nome: "Carlos Miguel", idade: 45, dinheiro: 1200.0)
    
    ricao.viver()
    ricao.fazCompras()

print("")
print("****** Pobre ******")
class Pobre : Pessoa {

    func trabalha() {
        print("\(nome!), pobre")
        print("idade: \(idade!), anos")
    }

    override func viver() {
        print(" \(nome!), é trabalhador")
    }
}
var pess = Pobre(nome: "Nereu Atos", idade: 40)

    pess.trabalha()
    pess.viver()

print("")
print("****** Miserável ******")
class Miseravel : Pessoa {

    func mendiga() {
        print(" \(nome!), mendiga")
    }

    override func viver() {
        print("\(idade!), anos")
        print(" \(nome!), vive morando na rua")
    }
}
var miseria = Miseravel(nome: "Jhonn Lee", idade: 70)

    miseria.mendiga()
    miseria.viver()
